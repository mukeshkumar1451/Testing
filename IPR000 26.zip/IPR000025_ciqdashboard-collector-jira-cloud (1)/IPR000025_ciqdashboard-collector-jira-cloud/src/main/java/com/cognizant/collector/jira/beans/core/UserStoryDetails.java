package com.cognizant.collector.jira.beans.core;


import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import lombok.Data;
import org.springframework.beans.BeanUtils;

@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
        "System.AreaPath",
        "System.TeamProject",
        "System.WorkItemType",
        "System.Title",
        "Microsoft.VSTS.Common.Priority"
})
public class UserStoryDetails {

    @JsonProperty("System.AreaPath")
    private String areaPath;
    @JsonProperty("System.TeamProject")
    private String teamProject;
    @JsonProperty("System.WorkItemType")
    private String workItemType;
    @JsonProperty("System.Title")
    private String title;
    @JsonProperty("Microsoft.VSTS.Common.Priority")
    private String priority;

    @JsonIgnore
    public JiraIssue getJiraIssue(){
        JiraIssue issue = new JiraIssue();
        BeanUtils.copyProperties(this, issue);
        return issue;
    }
}
