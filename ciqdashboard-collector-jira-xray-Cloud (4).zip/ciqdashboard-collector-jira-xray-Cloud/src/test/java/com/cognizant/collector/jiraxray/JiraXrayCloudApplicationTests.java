package com.cognizant.collector.jiraxray;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JiraXrayCloudApplicationTests {

	@Test
	void contextLoads() {
	}

}
