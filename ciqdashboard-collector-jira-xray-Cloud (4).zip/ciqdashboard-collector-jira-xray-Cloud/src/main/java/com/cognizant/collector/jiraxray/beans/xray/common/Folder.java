package com.cognizant.collector.jiraxray.beans.xray.common;

import com.fasterxml.jackson.annotation.*;

@lombok.Data
public class Folder {

    @JsonProperty("name")
    private String name;

    @JsonProperty("path")
    private String path;

}
