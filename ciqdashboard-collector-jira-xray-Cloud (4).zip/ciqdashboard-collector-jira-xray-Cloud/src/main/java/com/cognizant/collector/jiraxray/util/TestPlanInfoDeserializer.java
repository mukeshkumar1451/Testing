package com.cognizant.collector.jiraxray.util;

import com.cognizant.collector.jiraxray.beans.xray.plan.*;
import com.fasterxml.jackson.core.*;
import com.fasterxml.jackson.databind.*;
import lombok.extern.slf4j.*;

import java.io.*;
import java.util.*;

@Slf4j
public class TestPlanInfoDeserializer extends JsonDeserializer {

    @Override
    public TestPlanInfo deserialize(JsonParser jsonParser, DeserializationContext ctxt) throws IOException, JacksonException {

        JsonNode jsonNode = jsonParser.getCodec().readTree(jsonParser);
        var dataNode = jsonNode.get("data");
        var plansNode = dataNode.get(dataNode.fieldNames().next());

        return getTestPlans(jsonParser, plansNode);

    }

    private TestPlanInfo getTestPlans(JsonParser jsonParser, JsonNode testsNode) {

        TestPlanInfo testPlans = new TestPlanInfo();

        testsNode.fields().forEachRemaining(field -> {

            switch (field.getKey()) {

                case "total":
                    testPlans.setTotal(field.getValue().asInt());
                    break;
                case "start":
                    testPlans.setStart(field.getValue().asInt());
                    break;
                case "limit":
                    testPlans.setLimit(field.getValue().asInt());
                    break;
                case "results":
                    try {
                        testPlans.setTestPlans(Arrays.asList(jsonParser.getCodec().treeToValue(field.getValue(), TestPlan[].class)));
                    } catch (IOException e) {
                        log.warn("Unknown error occurred while deserializing test plans : {}", testsNode);
                    }
                    break;
            }

        });

        return testPlans;

    }
}
