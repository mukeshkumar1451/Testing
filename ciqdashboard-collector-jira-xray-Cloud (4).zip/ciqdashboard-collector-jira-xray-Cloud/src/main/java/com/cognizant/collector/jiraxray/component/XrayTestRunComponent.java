package com.cognizant.collector.jiraxray.component;

import com.cognizant.collector.jiraxray.beans.xray.XrayTestRun;
import com.cognizant.collector.jiraxray.beans.xray.plan.*;
import com.cognizant.collector.jiraxray.beans.xray.set.*;
import com.cognizant.collector.jiraxray.beans.xray.test.*;
import com.cognizant.collector.jiraxray.beans.xray.testrun.*;
import com.cognizant.collector.jiraxray.client.*;
import com.cognizant.collector.jiraxray.constants.*;
import com.cognizant.collector.jiraxray.service.*;
import com.fasterxml.jackson.core.*;
import com.fasterxml.jackson.databind.*;
import lombok.extern.slf4j.*;
import org.jetbrains.annotations.*;
import org.springframework.beans.factory.annotation.*;
import org.springframework.http.*;
import org.springframework.stereotype.*;
import org.springframework.util.*;

import javax.annotation.*;
import java.util.*;
import java.util.stream.*;

@Component
@Slf4j
public class XrayTestRunComponent {

    @Autowired
    XrayClient xrayClient;
    @Autowired
    CommonUtilComponent utilComponent;
    @Autowired
    XrayTestRunService xrayTestRunService;

    private HttpHeaders headers = new HttpHeaders();
    private ObjectMapper mapper = new ObjectMapper();

    @PostConstruct
    public void setHeaders() {
        headers = utilComponent.getHeaders();
    }

    private void getTestRuns(List<Test> tests) {

        boolean isCompleted = false;
        int start = Constant.PAGE_STARTS_AT, limit = Constant.RESULTS_PER_PAGE;

        do {

            var query = String.format(Constant.GET_TEST_RUNS_QUERY, "[\""+ tests.stream().map(Test::getId).collect(Collectors.joining("\",\"")) +"\"]" , limit, start);
            log.info("Xray: Query= {}", query);

            TestRunInfo testRuns = xrayClient.getTestRuns(headers, query);
            Stream<XrayTestRun> xrayTestRunDetails = testRuns.getTestRuns().parallelStream().map(TestRun::getXrayTestRun).peek(xrayTestRun -> tests.forEach(test -> {

                if(Objects.equals(xrayTestRun.getTestId(), test.getId())) {
                    xrayTestRun.setTestSets(test.getTestSetInfo().getTestSets().stream().map(TestSet::getId).collect(Collectors.joining(",")));
                    xrayTestRun.setTestPlans(test.getTestPlanInfo().getTestPlans().stream().map(TestPlan::getId).collect(Collectors.joining(",")));
                }

            }));

            log.info("Xray-Test-Runs count from server= {}", testRuns.getTestRuns().size());

            this.saveAllXrayTestRuns(xrayTestRunDetails);

            start += limit;

            if(testRuns.getTotal() < start) {
                isCompleted = true;
            }

        }
        while (!isCompleted);

    }

    private Test getTestSets(Test test) {

        boolean isCompleted = false;
        int start = Constant.PAGE_STARTS_AT, limit = Constant.RESULTS_PER_PAGE;

        while(true) {

            var query = String.format(Constant.GET_TEST_QUERY, "\""+test.getId()+"\"", limit, start, 1, 0);

            var testNode = xrayClient.getTest(headers, query).get("data").get("getTest");;
            Test currentTest = null;
            try {
                currentTest = mapper.treeToValue(testNode, Test.class);
            } catch (JsonProcessingException e) {
                log.warn("Unknown error occurred while parsing {}", testNode, e);
            }

            if( test.getTestSetInfo() == null ) {
                test.setTestSetInfo(currentTest.getTestSetInfo());
            }
            else {
                test.getTestSetInfo().setTotal(currentTest.getTestSetInfo().getTotal());
                test.getTestSetInfo().setLimit(currentTest.getTestSetInfo().getLimit());
                test.getTestSetInfo().setStart(currentTest.getTestSetInfo().getStart());
                test.getTestSetInfo().getTestSets().addAll(currentTest.getTestSetInfo().getTestSets());
            }

            start += limit;
            if(test.getTestSetInfo().getTotal() < start) {
                return test;
            }

        }
    }

    public Test getTestPlans(Test test) {

        int start = Constant.PAGE_STARTS_AT, limit = Constant.RESULTS_PER_PAGE;

        while(true) {

            var query = String.format(Constant.GET_TEST_QUERY, "\""+test.getId()+"\"", 1, 0, limit, start);
            var testNode = xrayClient.getTest(headers, query).get("data").get("getTest");;
            Test currentTest = null;
            try {
                currentTest = mapper.treeToValue(testNode, Test.class);
            } catch (JsonProcessingException e) {
                log.warn("Unknown error occurred while parsing {}", testNode, e);
            }

            if( test.getTestPlanInfo() == null ) {
                test.setTestPlanInfo(currentTest.getTestPlanInfo());
            }
            else {
                test.getTestPlanInfo().setTotal(currentTest.getTestPlanInfo().getTotal());
                test.getTestPlanInfo().setLimit(currentTest.getTestPlanInfo().getLimit());
                test.getTestPlanInfo().setStart(currentTest.getTestPlanInfo().getStart());
                test.getTestPlanInfo().getTestPlans().addAll(currentTest.getTestPlanInfo().getTestPlans());
            }

            start += limit;
            if(test.getTestPlanInfo().getTotal() < start) {
                return test;
            }

        }

    }

    public void getXrayTestRuns(String projectKey) {

        boolean isCompleted = false;
        int start = Constant.PAGE_STARTS_AT, limit = Constant.RESULTS_PER_PAGE;

        do {

            var getTestQuery = String.format(
                    Constant.GET_TESTS_QUERY, projectKey, limit, start, 1, 0, 1, 0
            );

            log.info("Xray-Tests: Query= {}", getTestQuery);

            TestInfo tests = xrayClient.getTests(
                    headers, getTestQuery
            );

            tests.getTests().forEach(test -> {
                test.setTestSetInfo(null);
                test.setTestPlanInfo(null);
                this.getTestSets(test);
                this.getTestPlans(test);
            });

            start += limit;

            if(tests.getTotal() < start) {
                isCompleted = true;
            }

            log.info("Tests collected= {}", tests.getTests().size());

            if(!CollectionUtils.isEmpty(tests.getTests())) {
                this.getTestRuns(tests.getTests());
            }

        }
        while (!isCompleted);
    }

    private void saveAllXrayTestRuns(@NotNull Stream<XrayTestRun> xrayTestRunDetails) {
        xrayTestRunService.saveAll(xrayTestRunDetails.collect(Collectors.toList()));
    }
}
