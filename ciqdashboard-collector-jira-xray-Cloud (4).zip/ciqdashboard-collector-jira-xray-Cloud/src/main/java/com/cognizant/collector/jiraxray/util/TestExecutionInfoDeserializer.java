package com.cognizant.collector.jiraxray.util;

import com.cognizant.collector.jiraxray.beans.xray.execution.*;
import com.fasterxml.jackson.core.*;
import com.fasterxml.jackson.databind.*;
import lombok.extern.slf4j.*;

import java.io.*;
import java.util.*;

@Slf4j
public class TestExecutionInfoDeserializer extends JsonDeserializer {

    @Override
    public TestExecutionInfo deserialize(JsonParser jsonParser, DeserializationContext ctxt) throws IOException, JacksonException {

        JsonNode jsonNode = jsonParser.getCodec().readTree(jsonParser);
        var dataNode = jsonNode.get("data");
        var testExecutionsNode = dataNode.get(dataNode.fieldNames().next());

        return getTestExecutions(jsonParser, testExecutionsNode);

    }

    private TestExecutionInfo getTestExecutions(JsonParser jsonParser, JsonNode testExecutionsNode) {

        TestExecutionInfo testExecutions = new TestExecutionInfo();

        testExecutionsNode.fields().forEachRemaining(field -> {

            switch (field.getKey()) {

                case "total":
                    testExecutions.setTotal(field.getValue().asInt());
                    break;
                case "start":
                    testExecutions.setStart(field.getValue().asInt());
                    break;
                case "limit":
                    testExecutions.setLimit(field.getValue().asInt());
                    break;
                case "results":
                    try {
                        testExecutions.setTestExecutions(Arrays.asList(jsonParser.getCodec().treeToValue(field.getValue(), TestExecution[].class)));
                    } catch (IOException e) {
                        log.warn("Unknown error occurred while deserializing test executions : {}", testExecutionsNode);
                    }
                    break;
            }

        });

        return testExecutions;

    }
}
