package com.cognizant.collector.jiraxray.beans.xray.precondition;

import com.cognizant.collector.jiraxray.util.*;
import com.fasterxml.jackson.annotation.*;
import com.fasterxml.jackson.databind.annotation.*;

@lombok.Data
@JsonDeserialize(using = PreConditionInfoDeserializer.class)
public class PreconditionInfo {

    @JsonProperty("total")
    private Integer total;

    @JsonProperty("start")
    private Integer start;

    @JsonProperty("limit")
    private Integer limit;

    @JsonProperty("results")
    private Precondition[] preconditions = new Precondition[0];

}
