/*
 *  © [2021] Cognizant. All rights reserved.
 *
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package com.cognizant.collector.jiraxray.constants;
/**
 * Constant
 * @author Cognizant
 */

public class Constant {

 public static final int RESULTS_PER_PAGE = 100;
 public static final int PAGE_STARTS_AT = 0;
 public static final String MAX_RESULTS = "maxResults";
 public static final String START_AT = "startAt";
 public static final String PROJECT = "project='%s'";
 public static final String JQL_UPDATED_LT = "updated < '%s' ";
 public static final String JQL_UPDATED_GTE = "updated >= '%s' ";
 public static final String JQL_AND = " AND ";
 public static final String JQL = "jql";
 public static final String SOURCE_JIRA ="source_jira_";

 /*Xray*/
 public static final String SOURCE_XRAY ="source_xray_";
 public static final String CLIENT_ID = "client_id";
 public static final String CLIENT_SECRET = "client_secret";
 public static final String GET_TESTS_QUERY = "{ getTests(jql: \"project = '%s'\", limit: %s, start: %s) { total start limit results { issueId testSets(limit: %s, start: %s) { start limit total results { issueId } } testPlans(limit: %s, start: %s) { start limit total results { issueId } } } } }";
 public static final String GET_TEST_QUERY = "{ getTest(issueId: %s) { issueId testSets(limit: %s, start: %s) { start limit total results { issueId } } testPlans(limit: %s, start: %s) { start limit total results { issueId } } } }";
 public static final String GET_TEST_RUNS_QUERY = "{ getTestRuns(testIssueIds: %s, limit: %s, start: %s) { total limit  start  results { id unstructured gherkin scenarioType comment startedOn defects executedById assigneeId finishedOn lastModified status {   name   final   description } testType {   id   name   kind } test {   issueId   jira(fields: [\"key\", \"project\", \"assignee\", \"reporter\"])   testType {  id  name  kind   }   unstructured   gherkin   folder {  name  path   }   scenarioType   lastModified } testExecution {   issueId   testEnvironments   lastModified   jira(fields: [\"key\", \"versions\", \"fixVersions\"]) } customFields {   id   name   values } parameters {   name   value }  } } } ";
 /*Xray*/

 private Constant() {
 }
}
