package com.cognizant.collector.jiraxray.beans.xray.testrun;

import com.cognizant.collector.jiraxray.beans.core.*;
import com.cognizant.collector.jiraxray.beans.xray.common.*;
import com.cognizant.collector.jiraxray.beans.xray.XrayTestRun;
import com.cognizant.collector.jiraxray.beans.xray.common.Status;
import com.cognizant.collector.jiraxray.beans.xray.execution.*;
import com.cognizant.collector.jiraxray.beans.xray.precondition.*;
import com.cognizant.collector.jiraxray.beans.xray.test.*;
import com.fasterxml.jackson.annotation.*;
import org.springframework.beans.*;
import org.springframework.util.*;

import java.util.*;

@lombok.Data
public class TestRun {

    @JsonProperty("id")
    private String id;

    @JsonProperty("unstructured")
    private String unstructured;

    @JsonProperty("gherkin")
    private String gherkin;

    @JsonProperty("scenarioType")
    private String scenarioType;

    @JsonProperty("comment")
    private String comment;

    @JsonProperty("startedOn")
    private Date startedOn;

    private String defects;

    @JsonProperty("executedById")
    private String executedById;

    @JsonProperty("assigneeId")
    private String assigneeId;

    @JsonProperty("finishedOn")
    private Date finishedOn;

    @JsonProperty("lastModified")
    private Date lastModified;

    @JsonProperty("status")
    private Status status;

    @JsonProperty("testType")
    private TestType testType;

    @JsonProperty("test")
    private Test test;

    private String testSets;
    private String testPlans;

    @JsonProperty("testExecution")
    private TestExecution testExecution;

    @JsonProperty("customFields")
    private Object[] customFields;

    @JsonProperty("parameters")
    private Object[] parameters;

    @JsonProperty("defects")
    public void setDefects(List<String> defects) {

        if(!ObjectUtils.isEmpty(defects)) {
            this.defects = String.join(",", defects);
        }

    }

    @JsonIgnore
    public XrayTestRun getXrayTestRun() {
        XrayTestRun xrayTestRun = new XrayTestRun();
        BeanUtils.copyProperties(this, xrayTestRun);

        this.setStatusInfo(xrayTestRun);
        this.setProjectInfo(xrayTestRun);
        this.setTestTypeInfo(xrayTestRun);
        this.setTestInfo(xrayTestRun);
        this.setTestExecutionInfo(xrayTestRun);
        this.setFixVersionsInfo(xrayTestRun);
        this.setPriority(xrayTestRun);

        return xrayTestRun;
    }

    @JsonIgnore
    private XrayTestRun setPriority(XrayTestRun xrayTestRun) {

        Object priority = this.test.getJiraFields().getPriority();

        if (priority == null) return xrayTestRun;
        xrayTestRun.setTestPriorityName((String) ((Map) priority).get("name"));
        xrayTestRun.setTestId((String) ((Map) priority).get("id"));

        return xrayTestRun;
    }

    @JsonIgnore
    private XrayTestRun setStatusInfo(XrayTestRun xrayTestRun) {

        xrayTestRun.setStatusFinal(this.status.getFinalStatus());
        xrayTestRun.setStatusName(this.status.getName());
        xrayTestRun.setStatusDescription(this.status.getDescription());

        return xrayTestRun;
    }

    @JsonIgnore
    private XrayTestRun setTestTypeInfo(XrayTestRun xrayTestRun) {

        xrayTestRun.setTestTypeId(this.testType.getId());
        xrayTestRun.setTestTypeName(this.testType.getName());
        xrayTestRun.setTestTypeKind(this.testType.getKind());

        return xrayTestRun;

    }

    @JsonIgnore
    private XrayTestRun setProjectInfo(XrayTestRun xrayTestRun) {

        xrayTestRun.setProjectId(this.test.getJiraFields().getProject().getId());
        xrayTestRun.setProjectKey(this.test.getJiraFields().getProject().getKey());
        xrayTestRun.setProjectName(this.test.getJiraFields().getProject().getName());
        xrayTestRun.setProjectTypeKey(this.test.getJiraFields().getProject().getProjectTypeKey());

        return xrayTestRun;
    }

    @JsonIgnore
    private XrayTestRun setFixVersionsInfo(XrayTestRun xrayTestRun) {

        List<FixVersion> fixVersions = this.testExecution.getJiraFields().getFixVersions();

        if (fixVersions == null || fixVersions.size() <= 0) return xrayTestRun;

        fixVersions.stream().findFirst().ifPresent(first -> {
            xrayTestRun.setFixVersionId(first.getId());
            xrayTestRun.setFixVersionName(first.getName());
            xrayTestRun.setFixVersionArchived(first.getArchived());
            xrayTestRun.setFixVersionReleased(first.getReleased());
            xrayTestRun.setFixVersionReleaseDate(first.getReleaseDate());
        });

        return xrayTestRun;

    }

    @JsonIgnore
    private XrayTestRun setTestInfo(XrayTestRun xrayTestRun) {

        xrayTestRun.setTestId(this.test.getId());
        xrayTestRun.setTestFolderName(this.test.getFolder().getName());
        xrayTestRun.setTestGherkin(this.test.getGherkin());
        xrayTestRun.setTestLastModified(this.test.getLastModified());
        xrayTestRun.setTestUnstructured(this.test.getUnstructured());
        xrayTestRun.setTestFolderPath(this.test.getFolder().getPath());
        xrayTestRun.setTestScenarioType(this.test.getScenarioType());

        xrayTestRun.setTestKey(this.test.getJiraFields().getIssueKey());

        if(this.test.getJiraFields().getAssignee() != null) {

            xrayTestRun.setTestAssigneeName(this.test.getJiraFields().getAssignee().getName());
            xrayTestRun.setTestAssigneeKey(this.test.getJiraFields().getAssignee().getKey());
            xrayTestRun.setTestAssigneeEmailAddress(this.test.getJiraFields().getAssignee().getEmailAddress());
            xrayTestRun.setTestAssigneeDisplayName(this.test.getJiraFields().getAssignee().getDisplayName());
            xrayTestRun.setTestAssigneeActive(this.test.getJiraFields().getAssignee().getActive());
            xrayTestRun.setTestAssigneeTimeZone(this.test.getJiraFields().getAssignee().getTimeZone());

        }

        if(this.test.getJiraFields().getReporter() != null) {
            xrayTestRun.setTestReporterName(this.test.getJiraFields().getReporter().getName());
            xrayTestRun.setTestReporterKey(this.test.getJiraFields().getReporter().getKey());
            xrayTestRun.setTestReporterEmailAddress(this.test.getJiraFields().getReporter().getEmailAddress());
            xrayTestRun.setTestReporterDisplayName(this.test.getJiraFields().getReporter().getDisplayName());
            xrayTestRun.setTestReporterActive(this.test.getJiraFields().getReporter().getActive());
            xrayTestRun.setTestReporterTimeZone(this.test.getJiraFields().getReporter().getTimeZone());
        }



        return xrayTestRun;
    }

    @JsonIgnore
    private XrayTestRun setTestExecutionInfo(XrayTestRun xrayTestRun) {

        xrayTestRun.setTestEnvironments(this.testExecution.getTestEnvironments());
        xrayTestRun.setTestExecId(this.testExecution.getId());
        xrayTestRun.setTestExecKey(this.testExecution.getJiraFields().getIssueKey());

        if(this.testExecution.getJiraFields().getAssignee() != null) {
            xrayTestRun.setTestExecAssigneeName(this.testExecution.getJiraFields().getAssignee().getName());
            xrayTestRun.setTestExecAssigneeKey(this.testExecution.getJiraFields().getAssignee().getKey());
            xrayTestRun.setTestExecAssigneeEmailAddress(this.testExecution.getJiraFields().getAssignee().getEmailAddress());
            xrayTestRun.setTestExecAssigneeDisplayName(this.testExecution.getJiraFields().getAssignee().getDisplayName());
            xrayTestRun.setTestExecAssigneeActive(this.testExecution.getJiraFields().getAssignee().getActive());
            xrayTestRun.setTestExecAssigneeTimeZone(this.testExecution.getJiraFields().getAssignee().getTimeZone());
        }

        if(this.testExecution.getJiraFields().getReporter() != null) {
            xrayTestRun.setTestExecReporterName(this.testExecution.getJiraFields().getReporter().getName());
            xrayTestRun.setTestExecReporterKey(this.testExecution.getJiraFields().getReporter().getKey());
            xrayTestRun.setTestExecReporterEmailAddress(this.testExecution.getJiraFields().getReporter().getEmailAddress());
            xrayTestRun.setTestExecReporterDisplayName(this.testExecution.getJiraFields().getReporter().getDisplayName());
            xrayTestRun.setTestExecReporterActive(this.testExecution.getJiraFields().getReporter().getActive());
            xrayTestRun.setTestExecReporterTimeZone(this.testExecution.getJiraFields().getReporter().getTimeZone());
        }
        xrayTestRun.setTestExecLastModified(this.testExecution.getLastModified());

        return xrayTestRun;
    }


}
