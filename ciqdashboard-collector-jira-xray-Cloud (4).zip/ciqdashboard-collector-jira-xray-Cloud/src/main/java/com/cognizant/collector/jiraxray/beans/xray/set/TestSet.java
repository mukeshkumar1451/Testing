package com.cognizant.collector.jiraxray.beans.xray.set;

import com.cognizant.collector.jiraxray.beans.xray.test.*;
import com.fasterxml.jackson.annotation.*;

import java.util.*;

@lombok.Data
public class TestSet {

    @JsonProperty("issueId")
    private String id;

    @JsonProperty("projectId")
    private String projectId;

    @JsonProperty("tests")
    private TestInfo tests;

    @JsonProperty("lastModified")
    private Date lastModified;

}
