package com.cognizant.collector.jiraxray.util;

import com.cognizant.collector.jiraxray.beans.xray.precondition.*;
import com.fasterxml.jackson.core.*;
import com.fasterxml.jackson.databind.*;

import java.io.*;

public class PreConditionInfoDeserializer extends JsonDeserializer {

    @Override
    public PreconditionInfo deserialize(JsonParser jsonParser, DeserializationContext ctxt) throws IOException, JacksonException {

        JsonNode jsonNode = jsonParser.getCodec().readTree(jsonParser);
        var dataNode = jsonNode.get("data");
        var preconditionsNode = dataNode.get(dataNode.fieldNames().next());

        return getPreconditions(jsonParser, preconditionsNode);

    }

    private PreconditionInfo getPreconditions(JsonParser jsonParser, JsonNode preconditionsNode) {

        PreconditionInfo preconditions = new PreconditionInfo();

        preconditionsNode.fields().forEachRemaining(field -> {

            switch (field.getKey()) {

                case "total":
                    preconditions.setTotal(field.getValue().asInt());
                    break;
                case "start":
                    preconditions.setStart(field.getValue().asInt());
                    break;
                case "limit":
                    preconditions.setLimit(field.getValue().asInt());
                    break;
                case "results":
                    try {
                        preconditions.setPreconditions(jsonParser.getCodec().treeToValue(field.getValue(), Precondition[].class));
                    } catch (IOException e) {
                        throw new RuntimeException(e);
                    }
                    break;
            }

        });

        return preconditions;

    }
}
