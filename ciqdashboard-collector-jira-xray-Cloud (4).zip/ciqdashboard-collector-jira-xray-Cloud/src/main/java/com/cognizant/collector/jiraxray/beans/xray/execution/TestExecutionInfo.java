package com.cognizant.collector.jiraxray.beans.xray.execution;

import com.cognizant.collector.jiraxray.util.*;
import com.fasterxml.jackson.annotation.*;
import com.fasterxml.jackson.databind.annotation.*;

import java.util.*;

@lombok.Data
@JsonDeserialize(using = TestExecutionInfoDeserializer.class)
public class TestExecutionInfo {

    @JsonProperty("total")
    private Integer total;

    @JsonProperty("start")
    private Integer start;

    @JsonProperty("limit")
    private Integer limit;

    @JsonProperty("results")
    private List<TestExecution> testExecutions = new ArrayList<>();

}
