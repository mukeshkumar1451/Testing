package com.cognizant.collector.jiraxray.util;

import com.cognizant.collector.jiraxray.beans.xray.set.*;
import com.fasterxml.jackson.core.*;
import com.fasterxml.jackson.databind.*;
import lombok.extern.slf4j.*;

import java.io.*;
import java.util.*;
import java.util.stream.*;

@Slf4j
public class TestSetInfoDeserializer extends JsonDeserializer {

    @Override
    public TestSetInfo deserialize(JsonParser jsonParser, DeserializationContext ctxt) throws IOException, JacksonException {

        JsonNode jsonNode = jsonParser.getCodec().readTree(jsonParser);
        var dataNode = jsonNode.get("data");
        var testSetsNode = dataNode.get(dataNode.fieldNames().next());

        return getTestRuns(jsonParser, testSetsNode);

    }

    private TestSetInfo getTestRuns(JsonParser jsonParser, JsonNode testsNode) {

        TestSetInfo testSets = new TestSetInfo();

        testsNode.fields().forEachRemaining(field -> {

            switch (field.getKey()) {

                case "total":
                    testSets.setTotal(field.getValue().asInt());
                    break;
                case "start":
                    testSets.setStart(field.getValue().asInt());
                    break;
                case "limit":
                    testSets.setLimit(field.getValue().asInt());
                    break;
                case "results":
                    try {
                        testSets.setTestSets(Arrays.asList(jsonParser.getCodec().treeToValue(field.getValue(), TestSet[].class)));
                    } catch (IOException e) {
                        log.warn("Unknown error occurred while deserializing test runs : {}", testsNode);
                    }
                    break;
            }

        });

        return testSets;

    }
}
