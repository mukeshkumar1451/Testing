package com.cognizant.collector.jiraxray.beans.xray.execution;

import com.cognizant.collector.jiraxray.beans.core.*;
import com.fasterxml.jackson.annotation.*;
import org.springframework.util.*;

import java.util.*;

@lombok.Data
public class TestExecution {

    @JsonProperty("issueId")
    private String id;

    private String testEnvironments;

    @JsonProperty("lastModified")
    private Date lastModified;

    @JsonProperty("jira")
    private Fields jiraFields;

    @JsonProperty("testEnvironments")
    public void setTestEnvironments(String[] testEnvironments) {
        if(!ObjectUtils.isEmpty(testEnvironments)) {
            this.testEnvironments = String.join(",", testEnvironments);
        }
    }
}
