package com.cognizant.collector.jiraxray.beans.xray.plan;

import com.cognizant.collector.jiraxray.beans.xray.execution.*;
import com.cognizant.collector.jiraxray.beans.xray.test.*;
import com.fasterxml.jackson.annotation.*;

import java.util.*;

@lombok.Data
public class TestPlan {

    @JsonProperty("issueId")
    private String id;

    @JsonProperty("projectId")
    private String projectId;

    @JsonProperty("tests")
    private TestInfo tests;

    @JsonProperty("testExecutions")
    private TestExecutionInfo testExecutions;

    @JsonProperty("folders")
    private String folders;

    @JsonProperty("lastModified")
    private Date lastModified;

}
