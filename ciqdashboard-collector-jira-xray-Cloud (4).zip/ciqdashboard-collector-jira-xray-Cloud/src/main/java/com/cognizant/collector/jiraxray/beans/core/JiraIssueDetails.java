package com.cognizant.collector.jiraxray.beans.core;

import lombok.*;

import java.util.*;

/**
 * JiraIssueDetails
 * @author Cognizant
 */

@Data
public class JiraIssueDetails {

    private String expand;
    private Integer maxResults;
    private Integer startAt;
    private Integer total;
    private List<JiraIssueInfo> issues = null;
    /*private Map<String, Object> additionalProperties = new HashMap<>();

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

     */

}