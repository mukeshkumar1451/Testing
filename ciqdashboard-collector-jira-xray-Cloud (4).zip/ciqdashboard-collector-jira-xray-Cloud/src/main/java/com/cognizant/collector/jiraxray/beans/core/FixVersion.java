package com.cognizant.collector.jiraxray.beans.core;

import lombok.*;

import java.util.*;
/**
 * FixVersion
 * @author Cognizant
 */

@Data
public class FixVersion {
    private String id;
    private String name;
    private Boolean archived;
    private Boolean released;
    private Date releaseDate;
}
