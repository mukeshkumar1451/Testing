/*
 *  © [2021] Cognizant. All rights reserved.
 *
 *     Licensed under the Apache License, Version 2.0 (the "License");
 *     you may not use this file except in compliance with the License.
 *     You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 *     Unless required by applicable law or agreed to in writing, software
 *     distributed under the License is distributed on an "AS IS" BASIS,
 *     WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *     See the License for the specific language governing permissions and
 *     limitations under the License.
 */

package com.cognizant.collector.jiraxray.component;

import com.cognizant.collector.jiraxray.client.*;
import com.cognizant.collector.jiraxray.constants.*;
import com.cognizant.collector.jiraxray.service.*;
import lombok.extern.slf4j.*;
import org.springframework.beans.factory.annotation.*;
import org.springframework.http.*;
import org.springframework.stereotype.*;
import org.springframework.util.*;

import javax.annotation.*;
import java.text.*;
import java.time.*;
import java.time.format.*;
import java.util.*;
import java.util.stream.*;

import static com.cognizant.collector.jiraxray.constants.Constant.*;

/**
 * CommonUtilComponent
 * @author Cognizant
 */

@Component
@Slf4j
public class CommonUtilComponent {

    @Autowired
    JiraIssueService service;
    @Autowired
    XrayClient xrayClient;

    @Value("${xrayServer.clientId}")
    private String clientId;
    @Value("${xrayServer.clientSecret}")
    private String clientSecret;

    HttpHeaders headers = new HttpHeaders();
    static String strLocale;
    static String timeZone;

    public HttpHeaders getHeaders() {
        return headers;
    }

    @PostConstruct
    public void setHeader() {

        LinkedHashMap<String, String> client = new LinkedHashMap<>();
        client.put(CLIENT_ID, clientId);
        client.put(CLIENT_SECRET, clientSecret);

        headers.set("Authorization","Bearer "+xrayClient.getToken(client));


    }

    public HttpHeaders getHeader() {
        return headers;
    }


    public static String accountId;

    static String jiraIssueCollectionName;

    static String xrayTestRunCollectionName;

    public static String getJiraIssueCollectionName() {
        return jiraIssueCollectionName;
    }

    @Value("${spring.data.mongodb.collection.issue}")
    public void setJiraIssueCollectionName(String jiraIssueCollectionName) {
        CommonUtilComponent.jiraIssueCollectionName = Constant.SOURCE_JIRA+jiraIssueCollectionName;
    }

    public static String getXrayTestRunCollectionName() {
        return xrayTestRunCollectionName;
    }

    @Value("${spring.data.mongodb.collection.testRun}")
    public void setXrayTestRunCollectionName(String xrayTestRunCollectionName) {
        CommonUtilComponent.xrayTestRunCollectionName = Constant.SOURCE_XRAY+xrayTestRunCollectionName;
    }

    public String parseDateToString(Date date) {

        if (null == date) {
            return "";
        }
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm");
        sdf.setTimeZone(TimeZone.getTimeZone(timeZone));
        return sdf.format(date);
    }

    public static LocalDateTime getDateTimeFromString(String dateTimeString) {

        LocalDateTime dateTime = null;

        if (!StringUtils.hasText(dateTimeString)) { return null; }

        try {
            dateTime = LocalDateTime.parse(dateTimeString, DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss.SSS"));
        }
        catch(DateTimeParseException e) {

            try {
                dateTime = LocalDateTime.parse(dateTimeString, DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss.SS"));
            }
            catch(DateTimeParseException f) {

                try {
                    dateTime = LocalDateTime.parse(dateTimeString, DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss.S"));
                }
                catch(DateTimeParseException g) {
                    log.info("Return value as null, due to exception while parsing string to date, Exception:{}");
                }

            }

        }
        return dateTime;
    }

    public static LocalDate getDateFromString(String dateString) {

        LocalDate date = null;

        if(!StringUtils.hasText(dateString)) {return null;}

        try{
            date = LocalDate.parse(dateString, DateTimeFormatter.ofPattern("dd/MMM/yy"));
        }
        catch(DateTimeParseException e) {
            try{
                date = LocalDate.parse(dateString, DateTimeFormatter.ofPattern("d/MMM/yy"));
            }
            catch(DateTimeParseException f) {
                log.info("Return value as null, due to exception while parsing string to date, Exception:{}");
            }
        }

        return date;
    }

    public Integer getIntegerFromString(String integerString) {
        Integer integer = null;
        try {
            integer = Integer.valueOf(integerString);
        } catch (NumberFormatException e) {
            log.info("Return value as null, due to exception while parsing string to integer, Exception:{}");
        }
        return integer;
    }

    public Map<String, String> getMap(String input) {
        Map<String, String> map = new HashMap<>();
        if (!(input.contains("[") && input.contains("]"))) return map;

        String[] strings = input.substring(input.indexOf('[') + 1, input.indexOf(']')).split(",");
        List<String> list = Arrays.asList(strings);
        list.forEach(s -> {
            String[] split = s.split("=");
            String key = split[0];
            if (split.length == 2) {
                String value = split[1].equals("<null>") ? null : split[1];
                map.put(key, value);
            }
        });

        return map;
    }

    public String getJqlParamString(String projectId, Date lastUpdatedDate) {
        List<String> jqlParams = new ArrayList<>();
        jqlParams.add(String.format(Constant.PROJECT, projectId));

        Date now = Calendar.getInstance().getTime();
        String nowDateSting = parseDateToString(now);

        jqlParams.add(String.format(Constant.JQL_UPDATED_LT, nowDateSting));
        if (!StringUtils.isEmpty(lastUpdatedDate)) {
            Calendar calendar = Calendar.getInstance();
            calendar.setTime(lastUpdatedDate);
            calendar.add(Calendar.MINUTE, 1);
            String updatedDateString = parseDateToString(calendar.getTime());
            jqlParams.add(String.format(Constant.JQL_UPDATED_GTE, updatedDateString));
        }
//        else {
//            String updatedDateString = parseDateToString(lastUpdatedDate);
//            jqlParams.add(String.format(JQL_UPDATED_GTE, updatedDateString));
//        }

        String jqlString = jqlParams.stream().collect(Collectors.joining(Constant.JQL_AND));
        log.info("JQL string : " + jqlString);
        return jqlString;
    }

    public String getJqlParamString(String projectId) {
        String jqlParam = String.format(Constant.PROJECT, projectId);
        return jqlParam;
    }

}
