package com.cognizant.collector.jiraxray.component;

import com.cognizant.collector.jiraxray.beans.Project;
import com.cognizant.collector.jiraxray.beans.core.*;
import com.cognizant.collector.jiraxray.client.*;
import lombok.extern.slf4j.*;
import org.springframework.beans.factory.annotation.*;
import org.springframework.stereotype.*;

import java.util.*;
import java.util.stream.*;

@Component
@Slf4j
public class JiraComponent {

    @Autowired
    JiraClient jiraClient;

    @Autowired
    JiraIssueComponent jiraIssueComponent;
    @Autowired
    XrayTestRunComponent XrayTestRunComponent;

    @Value("${jiraServer.projects}")
    private List<String> projectKeys;

    public List<Project> getProjects() {
        return jiraClient.getJiraProjects().stream().filter(project -> projectKeys.contains(project.getKey())).collect(Collectors.toList());
    }

    public void getIssues() {

        var serverInfo = jiraClient.getMySelf();

        CommonUtilComponent.strLocale = serverInfo.getLocale();
        CommonUtilComponent.timeZone = serverInfo.getTimeZone();

        getProjects().forEach(project -> {

            log.info("********* Project Name: {}", project.getName());

            jiraIssueComponent.getAllIssuesByProjectId(project);
            XrayTestRunComponent.getXrayTestRuns(project.getKey());

        });

    }
}
