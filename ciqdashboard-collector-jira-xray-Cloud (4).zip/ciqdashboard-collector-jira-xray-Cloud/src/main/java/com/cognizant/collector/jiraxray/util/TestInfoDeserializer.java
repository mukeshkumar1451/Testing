package com.cognizant.collector.jiraxray.util;

import com.cognizant.collector.jiraxray.beans.xray.test.*;
import com.fasterxml.jackson.core.*;
import com.fasterxml.jackson.databind.*;
import lombok.extern.slf4j.*;

import java.io.*;
import java.util.*;

@Slf4j
public class TestInfoDeserializer extends JsonDeserializer {

    @Override
    public TestInfo deserialize(JsonParser jsonParser, DeserializationContext ctxt) throws IOException, JacksonException {

        JsonNode jsonNode = jsonParser.getCodec().readTree(jsonParser);
        var dataNode = jsonNode.get("data");
        var testsNode = dataNode.get(dataNode.fieldNames().next());

        return getTests(jsonParser, testsNode);

    }

    private TestInfo getTests(JsonParser jsonParser, JsonNode testsNode) {

        TestInfo tests = new TestInfo();

        testsNode.fields().forEachRemaining(field -> {

            switch (field.getKey()) {

                case "total":
                    tests.setTotal(field.getValue().asInt());
                    break;
                case "start":
                    tests.setStart(field.getValue().asInt());
                    break;
                case "limit":
                    tests.setLimit(field.getValue().asInt());
                    break;
                case "results":
                    try {
                        tests.setTests(Arrays.asList(jsonParser.getCodec().treeToValue(field.getValue(), Test[].class)));
                    } catch (IOException e) {
                        log.warn("Unknown error occurred while deserializing tests : {}", testsNode);
                    }
                    break;
            }

        });

        return tests;

    }
}
