package com.cognizant.collector.jiraxray.beans.xray.precondition;

import com.cognizant.collector.jiraxray.beans.xray.common.*;
import com.cognizant.collector.jiraxray.beans.xray.test.*;
import com.fasterxml.jackson.annotation.*;
import lombok.*;

import java.util.*;

@Data
public class Precondition {

    class preconditionRef{

        @JsonProperty("issueId")
        private String id;

        @JsonProperty("projectId")
        private String projectId;

        @JsonProperty("preconditionType")
        private TestType preconditionType;

        @JsonProperty("definition")
        private String definition;

        @JsonProperty("tests")
        private TestInfo tests;

        @JsonProperty("folder")
        private Folder folder;

        @JsonProperty("lastModified")
        private Date lastModified;

    }

}
