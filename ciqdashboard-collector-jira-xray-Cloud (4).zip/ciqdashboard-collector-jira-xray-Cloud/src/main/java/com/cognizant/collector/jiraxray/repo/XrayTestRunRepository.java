package com.cognizant.collector.jiraxray.repo;

import com.cognizant.collector.jiraxray.beans.xray.*;
import org.springframework.data.mongodb.repository.*;

public interface XrayTestRunRepository extends MongoRepository<XrayTestRun, String> {


}
