package com.cognizant.collector.jiraxray.beans.xray.common;

import com.fasterxml.jackson.annotation.*;

@lombok.Data
public class TestType {

    @JsonProperty("id")
    private String id;

    @JsonProperty("name")
    private String name;

    @JsonProperty("kind")
    private String kind;

}
