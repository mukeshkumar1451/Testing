package com.cognizant.collector.jiraxray.client;

import com.cognizant.collector.jiraxray.beans.xray.test.*;
import com.cognizant.collector.jiraxray.beans.xray.testrun.*;
import com.fasterxml.jackson.databind.*;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.bind.annotation.RequestBody;

import java.util.*;

public interface XrayClient {

    @PostMapping(value = "/authenticate", consumes="application/json")
    String getToken(
            @RequestBody Map<String, String> json
    );

    @GetMapping("/graphql")
    TestInfo getTests(
            @RequestHeader HttpHeaders headers,
            @RequestParam String query
    );

    @GetMapping("/graphql")
    JsonNode getTest(
            @RequestHeader HttpHeaders headers,
            @RequestParam String query
    );

    @GetMapping("/graphql")
    TestRunInfo getTestRuns(
            @RequestHeader HttpHeaders headers,
            @RequestParam String query
    );

}
