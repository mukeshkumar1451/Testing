package com.cognizant.collector.jiraxray.beans.xray.common;

import com.fasterxml.jackson.annotation.*;

@lombok.Data
public class Status {

    @JsonProperty("name")
    private String name;

    @JsonProperty("description")
    private String description;

    @JsonProperty("final")
    private Boolean finalStatus;

}
