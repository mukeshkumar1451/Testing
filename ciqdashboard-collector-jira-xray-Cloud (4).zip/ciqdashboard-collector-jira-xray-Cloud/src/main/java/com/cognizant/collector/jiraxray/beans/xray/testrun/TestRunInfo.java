package com.cognizant.collector.jiraxray.beans.xray.testrun;

import com.cognizant.collector.jiraxray.util.*;
import com.fasterxml.jackson.annotation.*;
import com.fasterxml.jackson.databind.annotation.*;

import java.util.*;

@lombok.Data
@JsonDeserialize(using = TestRunInfoDeserializer.class)
public class TestRunInfo {

    @JsonProperty("total")
    private Integer total;

    @JsonProperty("start")
    private Integer start;

    @JsonProperty("limit")
    private Integer limit;

    @JsonProperty("results")
    private List<TestRun> testRuns = new ArrayList<>();

}
