package com.cognizant.collector.jiraxray.beans.core;

import com.cognizant.collector.jiraxray.util.*;
import com.fasterxml.jackson.databind.annotation.*;
import lombok.*;

/**
 * SprintDetails
 * @author Cognizant
 */

@Data
@NoArgsConstructor
@AllArgsConstructor
@JsonDeserialize(using = SprintDetailsDeserializer.class)
public class SprintDetails {
    private String sprintId;
    private Integer sprintRapidViewId;
    private String sprintState;
    private String sprintName;
    private Integer sprintSequence;
    private Object sprintGoal;
    private String sprintStartDate;
    private String sprintEndDate;
    private String sprintCompleteDate;
    private String sprintActivatedDate;
    private Boolean sprintAutoStartStop;
}
