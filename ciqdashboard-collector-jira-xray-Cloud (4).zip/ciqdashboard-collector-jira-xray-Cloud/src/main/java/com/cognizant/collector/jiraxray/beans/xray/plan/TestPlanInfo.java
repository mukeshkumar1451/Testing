package com.cognizant.collector.jiraxray.beans.xray.plan;

import com.cognizant.collector.jiraxray.util.*;
import com.fasterxml.jackson.annotation.*;
import com.fasterxml.jackson.databind.annotation.*;

import java.util.*;

@lombok.Data
//@JsonDeserialize(using = TestPlanInfoDeserializer.class)
public class TestPlanInfo {

    @JsonProperty("total")
    private Integer total;

    @JsonProperty("start")
    private Integer start;

    @JsonProperty("limit")
    private Integer limit;

    @JsonProperty("results")
    private List<TestPlan> testPlans = new ArrayList<>();

}
