package com.cognizant.collector.jiraxray.beans.xray.common;

import com.fasterxml.jackson.annotation.*;

@lombok.Data
public class Evidence {

    @JsonProperty("id")
    private String id;

    @JsonProperty("filename")
    private String fileName;

    @JsonProperty("storedInJira")
    private Boolean storedInJira;

    @JsonProperty("downloadLink")
    private String downloadLink;

    @JsonProperty("size")
    private Integer size;

    @JsonProperty("createdOn")
    private String createdOn;

}
