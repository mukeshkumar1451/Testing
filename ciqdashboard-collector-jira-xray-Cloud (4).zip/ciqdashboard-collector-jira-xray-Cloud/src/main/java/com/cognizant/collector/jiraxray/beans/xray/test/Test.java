package com.cognizant.collector.jiraxray.beans.xray.test;

import com.cognizant.collector.jiraxray.beans.core.*;
import com.cognizant.collector.jiraxray.beans.xray.common.*;
import com.cognizant.collector.jiraxray.beans.xray.plan.*;
import com.cognizant.collector.jiraxray.beans.xray.set.*;
import com.fasterxml.jackson.annotation.*;

import java.util.*;

@lombok.Data
public class Test {

    @JsonProperty("issueId")
    private String id;

    @JsonProperty("testType")
    private TestType testType;

    @JsonProperty("unstructured")
    private String unstructured;

    @JsonProperty("gherkin")
    private String gherkin;

    @JsonProperty("folder")
    private Folder folder;

    @JsonProperty("scenarioType")
    private String scenarioType;

    @JsonProperty("testPlans")
    private TestPlanInfo testPlanInfo;

    @JsonProperty("testSets")
    private TestSetInfo testSetInfo;

    @JsonProperty("lastModified")
    private Date lastModified;

    @JsonProperty("jira")
    private Fields jiraFields;

}
