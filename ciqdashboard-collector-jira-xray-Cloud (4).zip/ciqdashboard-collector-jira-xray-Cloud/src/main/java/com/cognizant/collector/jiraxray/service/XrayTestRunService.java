package com.cognizant.collector.jiraxray.service;

import com.cognizant.collector.jiraxray.beans.xray.*;
import com.cognizant.collector.jiraxray.repo.*;
import org.springframework.beans.factory.annotation.*;
import org.springframework.stereotype.*;

import java.util.*;

@Service
public class XrayTestRunService {

    @Autowired
    XrayTestRunRepository xrayTestRunRepository;

    public List<XrayTestRun> saveAll(List<XrayTestRun> xrayTestRunDetails) {
        return xrayTestRunRepository.saveAll(xrayTestRunDetails);
    }

}
