package com.cognizant.collector.jiraxray.beans.xray.set;

import com.cognizant.collector.jiraxray.util.*;
import com.fasterxml.jackson.annotation.*;
import com.fasterxml.jackson.databind.annotation.*;

import java.util.*;

@lombok.Data
//@JsonDeserialize(using = TestSetInfoDeserializer.class)
public class TestSetInfo {

    @JsonProperty("total")
    private Integer total;

    @JsonProperty("start")
    private Integer start;

    @JsonProperty("limit")
    private Integer limit;

    @JsonProperty("results")
    private List<TestSet> testSets = new ArrayList<>();

}
