package com.cognizant.collector.jira.service;

import com.cognizant.collector.jira.beans.zephyrscale.*;
import com.cognizant.collector.jira.db.repo.*;
import org.springframework.beans.factory.annotation.*;
import org.springframework.stereotype.*;

import java.util.*;

@Service
public class ZephyrScaleTestRunService {

    @Autowired
    ZephyrScaleTestRunRepository testRunRepository;

    public void saveAll(List<ZephyrScaleTestRun> testRuns) {
        testRunRepository.saveAll(testRuns);
    }

    public void save(ZephyrScaleTestRun testRun) {
        testRunRepository.save(testRun);
    }

    public ZephyrScaleTestRun getLastExecutedDateByFirstFolder(String projectKey, String firstFolderName) {
        return testRunRepository.findFirstByProjectKeyAndFirstFolderNameOrderByExecutionDateDesc(projectKey, firstFolderName);
    }

    public List<ZephyrScaleTestRun> getAllTestRunsByProjectAndFirstFolder(String projectKey, String firstFolderName) {
        return testRunRepository.findByProjectKeyAndFirstFolderName(projectKey, firstFolderName);
    }
}
