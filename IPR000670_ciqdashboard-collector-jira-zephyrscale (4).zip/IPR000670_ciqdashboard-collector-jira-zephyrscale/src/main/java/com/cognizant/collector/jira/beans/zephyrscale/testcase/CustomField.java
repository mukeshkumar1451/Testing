package com.cognizant.collector.jira.beans.zephyrscale.testcase;

import com.fasterxml.jackson.annotation.*;
import lombok.*;

@Data
public class CustomField {

    @JsonProperty("intValue")
    private Long intValue;

    @JsonProperty("stringValue")
    private String stringValue;

    @JsonProperty("customFieldId")
    private long customFieldId;

}
