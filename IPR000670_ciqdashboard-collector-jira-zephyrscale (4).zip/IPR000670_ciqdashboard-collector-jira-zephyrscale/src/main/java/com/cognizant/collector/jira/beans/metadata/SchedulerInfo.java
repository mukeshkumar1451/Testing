package com.cognizant.collector.jira.beans.metadata;

import lombok.*;
import org.springframework.data.annotation.*;
import org.springframework.data.mongodb.core.mapping.*;

import java.time.*;

@Data
@Document("scheduler_runs")
public class SchedulerInfo {

    @Id
    private String id;
    private LocalDateTime lastUpdatedDate;
    private String desc;
    private String toolName;

}
