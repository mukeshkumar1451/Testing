package com.cognizant.collector.jira.component;

import com.cognizant.collector.jira.beans.Project;
import com.cognizant.collector.jira.beans.zephyrscale.*;
import com.cognizant.collector.jira.beans.zephyrscale.folder.*;
import com.cognizant.collector.jira.beans.zephyrscale.testrun.*;
import com.cognizant.collector.jira.client.*;
import com.cognizant.collector.jira.service.*;
import feign.*;
import lombok.extern.slf4j.*;
import org.springframework.beans.factory.annotation.*;
import org.springframework.stereotype.*;
import org.springframework.util.*;

import java.util.*;
import java.util.stream.*;

import static com.cognizant.collector.jira.constants.Constant.*;

@Component
@Slf4j
public class ZephyrScaleTestRunComponent {

    @Autowired
    ZephyrScaleClient zephyrScaleClient;
    @Autowired
    JiraAuthComponent authComponent;
    @Autowired
    CommonUtilComponent utilComponent;
    @Autowired
    ZephyrScaleTestRunService zephyrScaleTestRunService;

    private List<TestRun> getTestRuns(int maxResults, int startAt, String projectKey, String folderName) {

        List<TestRun> testRuns = new ArrayList<TestRun>();

        try {
            testRuns.addAll(
                    zephyrScaleClient.getTestRuns(
                    authComponent.getCookies(),
                    maxResults,
                    startAt,
                    utilComponent.getZephyrScaleTestRunQuery(projectKey, folderName)
            ));
        }catch(FeignException e) {
            log.warn("No test runs found for the folder : {}", folderName);
        }

        return testRuns;
    }

    public void getZephyrScaleTestRuns(Project project, Folder folder) {

        boolean isCompleted = false;
        int startAt = PAGE_STARTS_AT;
        int maxResults = RUNS_PER_PAGE;

        do {

            log.info("Zephyr Query : {}, Max Results : {}, Starts At : {}"
                    , utilComponent.getZephyrScaleTestRunQuery(project.getKey(), folder.getName())
                    , maxResults
                    , startAt);

            List<TestRun> testRuns = this.getTestRuns(maxResults, startAt, project.getKey(), folder.getName());
            testRuns.forEach(testRun -> {
                log.info("Test Runs count from server : {}", testRun.getTestCases().size());
                this.saveTestRuns(testRun.getZephyrScaleTestRuns(project, folder).collect(Collectors.toList()));
            });

            if(CollectionUtils.isEmpty(testRuns)) {
                isCompleted = true;
            }

            startAt = startAt + maxResults;


        }while(!isCompleted);

    }

    public void setDayFlagsForTestRuns(String projectKey, String folderName) {
        log.info("Manipulating fields based on executionDate for Project : {} and Folder : {}", projectKey, folderName);
        var testRun = zephyrScaleTestRunService.getLastExecutedDateByFirstFolder(projectKey, folderName);
        Date lastExecutiondate = testRun!=null?testRun.getExecutionDate():null;
        if(lastExecutiondate != null ) {
            zephyrScaleTestRunService.getAllTestRunsByProjectAndFirstFolder(projectKey, folderName).forEach(testCaseExecution -> {
                Date actualExecdate = testCaseExecution.getExecutionDate();
                if(actualExecdate != null) {
                    long dif = utilComponent.getDifferenceBetweenDates(actualExecdate, lastExecutiondate);
                    if (dif <= 30) {
                        testCaseExecution.setDay30Flag("true");
                        if (dif <= 7) {
                            testCaseExecution.setDay7Flag("true");
                        }
                        zephyrScaleTestRunService.save(testCaseExecution);
                    }
                }
            });
        }
    }

    public void getZephyrScaleTestRuns(Project project) {

        zephyrScaleClient.getTestRunFolderTree(project.getId(), authComponent.getCookies())
                .getFolders().forEach(folder -> {
                    log.info("*********Folder Name : {}", folder.getName());
                    this.getZephyrScaleTestRuns(project, folder);
                    this.setDayFlagsForTestRuns(project.getKey(), folder.getName());
                });

    }

    private void saveTestRuns(List<ZephyrScaleTestRun> zephyrScaleTestRuns) {
        zephyrScaleTestRunService.saveAll(zephyrScaleTestRuns);
        log.info("Test Runs stored in DB, Count: {}", zephyrScaleTestRuns.size());
    }

}
