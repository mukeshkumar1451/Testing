package com.cognizant.collector.jira.beans.core;

import com.fasterxml.jackson.annotation.*;
import lombok.*;

@Data
public class IssueLink {

    @JsonProperty("inwardIssue")
    private JiraIssueInfo inwardIssue;

    @JsonProperty("outwardIssue")
    private JiraIssueInfo outwardIssue;

    private String parentId;

}
