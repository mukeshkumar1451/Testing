package com.cognizant.collector.jira.beans.zephyrscale.folder;

import com.fasterxml.jackson.annotation.*;
import lombok.*;

import java.util.*;
// the api that is used to fetch the folder is  getTestCaseFolderTree()
@Data
public class FolderTree {

    @JsonProperty("projectId")
    private long projectId;

    @JsonProperty("itemsCount")
    private long itemsCount;

    @JsonProperty("children")
    private List<Folder> folders = new ArrayList<>();

}
