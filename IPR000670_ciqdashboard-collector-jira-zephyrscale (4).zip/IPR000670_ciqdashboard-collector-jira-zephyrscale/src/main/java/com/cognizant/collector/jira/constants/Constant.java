/*
 *  © [2021] Cognizant. All rights reserved.
 *
 *     Licensed under the Apache License, Version 2.0 (the "License");
 *     you may not use this file except in compliance with the License.
 *     You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 *     Unless required by applicable law or agreed to in writing, software
 *     distributed under the License is distributed on an "AS IS" BASIS,
 *     WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *     See the License for the specific language governing permissions and
 *     limitations under the License.
 */

package com.cognizant.collector.jira.constants;
/**
 * Constant
 * @author Cognizant
 */

public class Constant {

    public static final String TOOL_NAME = "Jira";
    public static final String JIRA_PLUGIN_NAME = "ZephyrScale";

    /*JIRA*/
    public static final int RESULTS_PER_PAGE = 50;
    public static final int PAGE_STARTS_AT = 0;
    public static final String MAX_RESULTS = "maxResults";
    public static final String START_AT = "startAt";
    public static final String PROJECT = "project='%s'";
    public static final String JQL_UPDATED_LT = "updated < '%s' ";
    public static final String JQL_UPDATED_GTE = "updated >= '%s' ";
    public static final String JQL_AND = " AND ";

    public static final String JQL_ORDER_BY_UPDATED = " ORDER BY updated ASC";

    public static final String JQL = "jql";
    public static final String SOURCE_JIRA ="source_jira_";
    /*JIRA*/

    /*ZEPHYR SCALE*/
    public static final String TEST_RUN_QUERY = "projectKey = \"%s\" AND folder = \"/%s\"";
    public static final String SOURCE_ZEPHYR ="source_zephyrscale_";
    public static final int RUNS_PER_PAGE = 2;
    public static final String TEST_CASE_QUERY = "testCase.projectId IN (%s) AND testCase.folderTreeId IN (%s)";
    public static final String FIELDS = "id,createdOn,createdBy,updatedOn,updatedBy,folderId,projectId,archived,key,name,objective,majorVersion,latestVersion,labels,latestVersion,precondition,folder(id,name),status(id,name,isDefault),priority(id,name,isDefault),estimatedTime,averageTime,customFieldValues,componentId,owner,labels,lastTestResultStatus(id,name,isDefault)";
    /*ZEPHYR SCALE*/

    private Constant() {
    }
}
