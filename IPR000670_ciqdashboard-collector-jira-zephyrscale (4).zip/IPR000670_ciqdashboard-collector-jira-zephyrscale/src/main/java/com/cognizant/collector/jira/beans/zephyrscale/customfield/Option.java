package com.cognizant.collector.jira.beans.zephyrscale.customfield;

import com.fasterxml.jackson.annotation.*;
import lombok.*;

@Data
public class Option {

    @JsonProperty("archived")
    private boolean archived;

    @JsonProperty("name")
    private String name;

    @JsonProperty("index")
    private long index;

    @JsonProperty("id")
    private long id;

}
