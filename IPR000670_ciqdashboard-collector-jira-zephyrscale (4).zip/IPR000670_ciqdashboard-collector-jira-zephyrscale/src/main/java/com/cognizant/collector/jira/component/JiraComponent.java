package com.cognizant.collector.jira.component;

import com.cognizant.collector.jira.beans.*;
import com.cognizant.collector.jira.client.*;
import lombok.extern.slf4j.*;
import org.springframework.beans.factory.annotation.*;
import org.springframework.stereotype.*;

import java.util.*;
import java.util.stream.*;

@Component
@Slf4j
public class JiraComponent {

    @Autowired
    JiraClient client;
    @Autowired
    JiraAuthComponent jiraAuthComponent;
    @Autowired
    JiraIssueComponent jiraIssueComponent;
    @Autowired
    ZephyrScaleTestRunComponent zephyrScaleTestRunComponent;
    @Autowired
    ZephyrScaleTestCaseComponent zephyrScaleTestCaseComponent;

    @Value("${jiraServer.projects}")
    private List<String> projectKeys;

    public List<Project> getProjects(String cookies) {
        return client.getJiraProjects(cookies).stream().filter(project -> projectKeys.contains(project.getKey())).collect(Collectors.toList());
    }

    public void getJiraComponents() {
     //   System.out.println("Cokkies");
     //   System.out.println(jiraAuthComponent.getCookies());

        var serverInfo = client.getMySelf(jiraAuthComponent.getCookies());

        CommonUtilComponent.strLocale = serverInfo.getLocale();
        CommonUtilComponent.timeZone = serverInfo.getTimeZone();

        List<Project> projects = getProjects(jiraAuthComponent.getCookies());

        projects.forEach(project -> {
            log.info("********* Project Name: {}", project.getName());
            jiraIssueComponent.getAllIssuesByProjectId(project);
            zephyrScaleTestCaseComponent.getZephyrScaleTestCases(project);
            zephyrScaleTestRunComponent.getZephyrScaleTestRuns(project);
        });

    }

}
