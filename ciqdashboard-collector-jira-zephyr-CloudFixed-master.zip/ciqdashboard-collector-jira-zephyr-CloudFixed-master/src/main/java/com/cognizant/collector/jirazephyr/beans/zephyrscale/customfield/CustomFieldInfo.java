package com.cognizant.collector.jirazephyr.beans.zephyrscale.customfield;

import com.cognizant.collector.jira.util.*;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import lombok.Data;

import java.util.HashMap;
import java.util.Map;

@Data
@JsonDeserialize(using = CustomFieldInfoDeserializer.class)
public class CustomFieldInfo {

    private Map<Long, CustomField> customFields= new HashMap<>();

}
