package com.cognizant.collector.jirazephyr.beans.zephyrscale.customfield;

import com.cognizant.collector.jira.util.*;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import lombok.Data;

import java.util.HashMap;
import java.util.Map;

@Data
@JsonDeserialize(using = OptionInfoDeserializer.class)
public class OptionInfo {

    Map<Long, Option> options = new HashMap<Long, Option>();

}
