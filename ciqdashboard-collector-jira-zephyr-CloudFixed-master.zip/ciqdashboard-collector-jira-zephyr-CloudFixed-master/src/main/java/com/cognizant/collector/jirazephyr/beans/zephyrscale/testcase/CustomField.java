package com.cognizant.collector.jirazephyr.beans.zephyrscale.testcase;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
public class CustomField {

    @JsonProperty("intValue")
    private Long intValue;

    @JsonProperty("stringValue")
    private String stringValue;

    @JsonProperty("customFieldId")
    private long customFieldId;

}
