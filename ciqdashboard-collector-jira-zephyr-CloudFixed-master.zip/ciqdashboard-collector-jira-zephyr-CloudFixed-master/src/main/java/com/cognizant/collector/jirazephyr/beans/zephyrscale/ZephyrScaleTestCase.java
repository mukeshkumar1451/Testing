package com.cognizant.collector.jirazephyr.beans.zephyrscale;




import java.util.Date;
//        import com.cognizant.collector.jira.beans.zephyrscale.testcase.*;
//        import com.cognizant.collector.jira.component.CommonUtilComponent;
//        import com.fasterxml.jackson.annotation.JsonProperty;
        import lombok.*;
       import org.springframework.data.annotation.*;
        import org.springframework.data.mongodb.core.mapping.*;



@Data
@Document(collection = "#{T(com.cognizant.collector.jira.component.CommonUtilComponent).getZephyrCollectionName()}")
public class ZephyrScaleTestCase {

    @Id
    @Field("Key")
    private String key;

    private long id;
    private String name;
    private long majorVersion;
    private String type = "Test Case";

    /* Project */
    private long projectId;
    private String projectKey;
    private String projectName;
    /* Project */

    private Long folderId;
    private String folderName;

    private Date createdOn;
    private String createdBy;
    private Date updatedOn;
    private String updatedBy;

    /* Priority */
    private Long priorityId;
    private String priorityName;
    private Long priorityIndex;
    private Boolean priorityIsDefault;
    /* Priority */

    /* Status */
    private Long statusId;
    private String statusName;
    private Long statusIndex;
    private Boolean statusIsDefault;
    /* Status */

    /* Last Test Result */
    private Long lastTestResultStatusId;
    private String lastTestResultStatusName;
    private Boolean lastTestResultStatusIsDefault;
    /* Last Test Result */

    private String[] labels;

    /* Folder */
    private Long dropId;
    /* Folder */

    /* Sub-Folder:child(1) */
    private Long moduleId;
    private String moduleName;
    /* Sub-Folder:child(1) */

    /* Sub-Folder:child(2) */
    private Long subModuleId;
    private String subModuleName;
    /* Sub-Folder:child(2) */

    /* CustomFields */
    private String testType;
    private String testEnvironment;
    private String dropName;
    private String cycleName;
    private String srClassification;
    private String srType;
    private String language;
    private String reqIdAll;
    private String reqId;
    private String srAction;
    private String wave;
    private String srArea;
    private String srSubArea;
    private String release;
    private String useCaseId;
    /* CustomFields */

    private Long averageTime;
    private boolean archived;
    private boolean latestVersion;

}

