package com.cognizant.collector.jirazephyr.component;

import com.cognizant.collector.jirazephyr.beans.Project;
import com.cognizant.collector.jirazephyr.beans.zephyrscale.ZephyrScaleTestCase;
import com.cognizant.collector.jirazephyr.beans.zephyrscale.customfield.CustomFieldInfo;
import com.cognizant.collector.jirazephyr.beans.zephyrscale.testcase.TestCaseInfo;
import com.cognizant.collector.jirazephyr.client.ZephyrScaleClient;
import com.cognizant.collector.jirazephyr.constants.Constant;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.CollectionUtils;
import com.cognizant.collector.jirazephyr.service.*;
import java.util.List;
import java.util.stream.Collectors;

import static com.cognizant.collector.jirazephyr.constants.Constant.PAGE_STARTS_AT;
import static com.cognizant.collector.jirazephyr.constants.Constant.RESULTS_PER_PAGE;



public class ZephyrScaleTestCaseComponent {
    @Autowired
    ZephyrScaleClient zephyrScaleClient;

    @Autowired
    CommonUtilComponent utilComponent;

    @Autowired
    ZephyrScaleTestCaseService testCaseService;

    private void getTestCases(Project project) {

        int resultPerPage = RESULTS_PER_PAGE;
        int startAt = PAGE_STARTS_AT;
        boolean isCompleted = false;

        do {

            TestCaseInfo testCaseInfo = ZephyrScaleClient.getTestCases(
                   // utilComponent.getCookies(),
                    resultPerPage,
                    startAt,
                    utilComponent.getZephyrScaleTestCaseQuery(project.getId()),
                    Constant.FIELDS
            );

            log.info("ZephyrScale Query : {}, StartAt : {}, MaxResults : {}", utilComponent.getZephyrScaleTestCaseQuery(project.getId()), startAt, resultPerPage);

            List<ZephyrScaleTestCase> zephyrScaleTestCases = testCaseInfo.getTestCases().stream().map(testCase -> {
                ZephyrScaleTestCase zephyrScaleTestCase = new ZephyrScaleTestCase();
                zephyrScaleTestCase.setProjectName(project.getName());
                zephyrScaleTestCase.setProjectKey(project.getKey());
                utilComponent.setCustomFieldDetails(zephyrScaleTestCase, testCase.getCustomFieldValues(), customFieldInfo);
                return testCase.getZephyrScaleTestCase(zephyrScaleTestCase);
            }).collect(Collectors.toList());


            if (CollectionUtils.isEmpty(zephyrScaleTestCases)) {
                isCompleted = true;
            } else {
                startAt += resultPerPage;
                if (testCaseInfo.getTotal() < startAt) isCompleted = true;
                log.info("TestCases count form server : {}", zephyrScaleTestCases.size());
                testCaseService.saveAll(zephyrScaleTestCases);
            }

        }
        while(!isCompleted);

    }


    public void getZephyrScaleTestCases(Project project) {

        CustomFieldInfo customFieldInfo = ZephyrScaleClient.getCustomFields(
                project.getId(),
               // authComponent.getCookies()
        );

//        zephyrScaleClient.getTestCaseFolderTree(project.getId(), authComponent.getCookies())
//                .getFolders().parallelStream().forEach(folder -> {
//                    log.info("*********Folder Name : {}", folder.getName());
//                    this.getTestCasesByFolderId(project, folder, customFieldInfo);
//                });

    }

}
