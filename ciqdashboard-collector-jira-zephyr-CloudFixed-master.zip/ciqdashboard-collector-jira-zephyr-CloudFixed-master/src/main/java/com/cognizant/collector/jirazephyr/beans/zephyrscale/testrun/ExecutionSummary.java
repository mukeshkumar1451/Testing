package com.cognizant.collector.jirazephyr.beans.zephyrscale.testrun;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
public class ExecutionSummary {

    @JsonProperty("Not Executed")
    private int notExecuted;
    @JsonProperty("Deferred")
    private int deferred;

}
