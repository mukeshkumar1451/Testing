package com.cognizant.collector.jirazephyr.service;

import com.cognizant.collector.jirazephyr.beans.zephyrscale.ZephyrScaleTestCase;
import com.cognizant.collector.jirazephyr.db.repo.ZephyrScaleTestCaseRepository;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.List;

public class ZephyrScaleTestCaseService {
    @Autowired
    ZephyrScaleTestCaseRepository testcaseRepository;

    public void saveAll(List<ZephyrScaleTestCase> testCases) {
        testcaseRepository.saveAll(testCases);
    }

    public void save(ZephyrScaleTestCase testCase) {
        testcaseRepository.save(testCase);
    }
}
