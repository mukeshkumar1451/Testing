package com.cognizant.collector.jirazephyr.beans.zephyrscale.customfield;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
public class CustomField {

    @JsonProperty("id")
    private long id;

    @JsonProperty("name")
    private String name;

    @JsonProperty("projectId")
    private long projectId;

    @JsonProperty("index")
    private long index;

    @JsonProperty("options")
    OptionInfo optionInfo;

    @JsonProperty("type")
    private String type;

    @JsonProperty("archived")
    private boolean archived;

    @JsonProperty("required")
    private boolean required;

}
