package com.cognizant.collector.jirazephyr.beans.zephyrscale.testcase;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

import java.util.ArrayList;
import java.util.List;

@Data
public class TestCaseInfo {

    @JsonProperty("results")
    private List<TestCase> testCases = new ArrayList<TestCase>();

    @JsonProperty("total")
    private long total;

    @JsonProperty("startAt")
    private long startAt;

    @JsonProperty("maxResults")
    private long maxResults;

    @JsonProperty("last")
    private boolean last;

}
