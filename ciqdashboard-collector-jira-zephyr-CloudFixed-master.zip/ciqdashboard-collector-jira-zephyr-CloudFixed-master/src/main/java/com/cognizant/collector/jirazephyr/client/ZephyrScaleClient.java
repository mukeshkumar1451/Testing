package com.cognizant.collector.jirazephyr.client;

import com.cognizant.collector.jirazephyr.beans.zephyrscale.*;
import com.cognizant.collector.jirazephyr.beans.zephyrscale.customfield.CustomFieldInfo;
import com.cognizant.collector.jirazephyr.beans.zephyrscale.testcase.TestCaseInfo;
import org.springframework.web.bind.annotation.*;

import java.util.*;

public interface ZephyrScaleClient {



    @GetMapping("/testcase")
    TestCaseInfo getTestCases(
         //  @RequestHeader("Cookie") String strCookie,
            @RequestParam("maxResults") int maxResults,
            @RequestParam("startAt") int startAt,
            @RequestParam("query") String query,
            @RequestParam("fields") String fields
    );

}
