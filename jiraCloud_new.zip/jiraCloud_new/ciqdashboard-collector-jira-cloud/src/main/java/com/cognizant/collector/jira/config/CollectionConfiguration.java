package com.cognizant.collector.jira.config;

import lombok.*;
import org.springframework.boot.context.properties.*;
import org.springframework.context.annotation.*;

import java.util.*;

@Configuration
@ConfigurationProperties(value = "spring.data.mongodb.collection")
@Data
public class CollectionConfiguration {
    private Map<String, List<String>> mapping;
}
