package com.cognizant.collector.jira.component;

import com.cognizant.collector.jira.beans.Project;
import com.cognizant.collector.jira.beans.core.*;
import com.cognizant.collector.jira.client.*;
import com.cognizant.collector.jira.config.*;
import lombok.extern.slf4j.*;
import org.springframework.beans.factory.annotation.*;
import org.springframework.stereotype.*;
import org.springframework.util.*;

import java.util.*;
import java.util.stream.*;

@Component
@Slf4j
public class JiraComponent {

    @Autowired
    CollectionConfiguration collectionConfiguration;

    @Autowired
    JiraClient client;

    @Autowired
    JiraIssueComponent jiraIssueComponent;

    @Autowired
    CommonUtilComponent utilComponent;

    @Value("${jiraServer.projects}")
    private List<String> projectKeys;

    public void getJiraIssues() {
        List<Project> projects = getProjects();

            projects.forEach(project -> {
            log.info("********* Project Name: {}", project.getName());
                List<IssueType> issueTypes = this.getIssueTypes(project.getId());
                collectionConfiguration.getMapping().keySet().forEach(key -> {
                    utilComponent.setCollectionName(key);
                    String issueTypesAsString = issueTypes.stream().filter(issueType-> collectionConfiguration.getMapping().get(key).contains(issueType.getName())).map(IssueType::getName).collect(Collectors.joining(","));
                    if(!StringUtils.isEmpty(issueTypesAsString)) {
                        System.out.println(key + "    " + issueTypesAsString);
                        jiraIssueComponent.getAllIssuesByProjectId(project, issueTypesAsString);
                    };
            });
        });
    }

    private List<IssueType> getIssueTypes(String projectId) {
        return client.getIssueTypes(projectId);
    }

    public List<Project> getProjects() {
        return client.getJiraProjects().stream().filter(project -> projectKeys.contains(project.getKey())).collect(Collectors.toList());
    }


}
